-- =========================================================
-- ModChat Database Schema
-- Aplikasi chat mirip WhatsApp tanpa nomor HP / SIM card.
-- Setiap user diidentifikasi dengan "ModChat ID" 5 digit acak.
-- =========================================================

CREATE DATABASE IF NOT EXISTS modchat CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE modchat;

-- ---------------------------------------------------------
-- USERS
-- ---------------------------------------------------------
CREATE TABLE users (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    modchat_id      CHAR(5)      NOT NULL UNIQUE,   -- ID 5 angka acak (pengganti no. HP)
    name            VARCHAR(60)  NOT NULL,
    username        VARCHAR(40)  NOT NULL UNIQUE,
    password_hash   VARCHAR(255) NOT NULL,
    avatar          VARCHAR(255) DEFAULT NULL,
    bio             VARCHAR(150) DEFAULT 'Halo, saya pakai ModChat!',
    chat_background VARCHAR(255) DEFAULT NULL,
    language        VARCHAR(10)  DEFAULT 'id',
    status_privacy  ENUM('all','contacts','nobody') DEFAULT 'all',
    last_seen       DATETIME     DEFAULT NULL,
    is_online       TINYINT(1)   DEFAULT 0,
    created_at      DATETIME     DEFAULT CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------
-- CONTACTS (buku alamat pribadi tiap user)
-- ---------------------------------------------------------
CREATE TABLE contacts (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    owner_id        INT NOT NULL,               -- pemilik daftar kontak
    contact_user_id INT NOT NULL,               -- user yang disimpan
    saved_name      VARCHAR(60) NOT NULL,        -- nama simpanan (custom)
    role            VARCHAR(30) DEFAULT NULL,    -- opsional: teman/guru/bos/dll
    is_blocked      TINYINT(1) DEFAULT 0,
    is_muted        TINYINT(1) DEFAULT 0,
    created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_contact (owner_id, contact_user_id),
    FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (contact_user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ---------------------------------------------------------
-- CHATS (wadah umum: privat, grup, atau saluran/channel)
-- ---------------------------------------------------------
CREATE TABLE chats (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    type        ENUM('private','group','channel') NOT NULL,
    name        VARCHAR(60)  DEFAULT NULL,   -- dipakai utk grup/channel
    avatar      VARCHAR(255) DEFAULT NULL,
    description VARCHAR(255) DEFAULT NULL,
    created_by  INT NOT NULL,
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
);

-- ---------------------------------------------------------
-- CHAT MEMBERS
-- ---------------------------------------------------------
CREATE TABLE chat_members (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    chat_id     INT NOT NULL,
    user_id     INT NOT NULL,
    role        ENUM('member','admin','owner') DEFAULT 'member',
    joined_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_member (chat_id, user_id),
    FOREIGN KEY (chat_id) REFERENCES chats(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ---------------------------------------------------------
-- PER-USER CHAT SETTINGS (arsip, mute, background per chat)
-- ---------------------------------------------------------
CREATE TABLE chat_user_settings (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    chat_id     INT NOT NULL,
    user_id     INT NOT NULL,
    is_archived TINYINT(1) DEFAULT 0,
    is_muted    TINYINT(1) DEFAULT 0,
    is_pinned   TINYINT(1) DEFAULT 0,
    background  VARCHAR(255) DEFAULT NULL,
    UNIQUE KEY uniq_setting (chat_id, user_id),
    FOREIGN KEY (chat_id) REFERENCES chats(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ---------------------------------------------------------
-- MESSAGES
-- ---------------------------------------------------------
CREATE TABLE messages (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    chat_id     INT NOT NULL,
    sender_id   INT NOT NULL,
    type        ENUM('text','image','file','voice','video','system') DEFAULT 'text',
    content     TEXT DEFAULT NULL,          -- isi teks / caption
    file_path   VARCHAR(255) DEFAULT NULL,  -- path media (foto/file/voice note)
    reply_to    INT DEFAULT NULL,           -- id pesan yang dibalas
    is_edited   TINYINT(1) DEFAULT 0,
    is_deleted  TINYINT(1) DEFAULT 0,
    is_pinned   TINYINT(1) DEFAULT 0,
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (chat_id) REFERENCES chats(id) ON DELETE CASCADE,
    FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (reply_to) REFERENCES messages(id) ON DELETE SET NULL
);

-- ---------------------------------------------------------
-- MESSAGE STATUS (sent/delivered/read per penerima)
-- ---------------------------------------------------------
CREATE TABLE message_status (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    message_id  INT NOT NULL,
    user_id     INT NOT NULL,
    status      ENUM('sent','delivered','read') DEFAULT 'sent',
    updated_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_status (message_id, user_id),
    FOREIGN KEY (message_id) REFERENCES messages(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ---------------------------------------------------------
-- STATUS / STORY (mirip WhatsApp Status, hidup 24 jam)
-- ---------------------------------------------------------
CREATE TABLE statuses (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NOT NULL,
    type        ENUM('image','text') DEFAULT 'image',
    file_path   VARCHAR(255) DEFAULT NULL,
    caption     VARCHAR(255) DEFAULT NULL,
    bg_color    VARCHAR(20) DEFAULT NULL,   -- untuk status teks
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
    expires_at  DATETIME NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE status_views (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    status_id   INT NOT NULL,
    viewer_id   INT NOT NULL,
    viewed_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_view (status_id, viewer_id),
    FOREIGN KEY (status_id) REFERENCES statuses(id) ON DELETE CASCADE,
    FOREIGN KEY (viewer_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ---------------------------------------------------------
-- CALLS (riwayat panggilan suara/video)
-- ---------------------------------------------------------
CREATE TABLE calls (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    chat_id     INT NOT NULL,
    caller_id   INT NOT NULL,
    receiver_id INT NOT NULL,
    type        ENUM('voice','video') DEFAULT 'voice',
    status      ENUM('missed','answered','declined','outgoing') DEFAULT 'outgoing',
    started_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
    ended_at    DATETIME DEFAULT NULL,
    duration_sec INT DEFAULT 0,
    FOREIGN KEY (chat_id) REFERENCES chats(id) ON DELETE CASCADE,
    FOREIGN KEY (caller_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ---------------------------------------------------------
-- CALL SIGNALS (signaling sederhana utk WebRTC voice/video call
-- lewat polling, dipasangkan dgn tabel calls di atas)
-- ---------------------------------------------------------
CREATE TABLE call_signals (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    call_id     INT NOT NULL,
    from_user   INT NOT NULL,
    to_user     INT NOT NULL,
    type        ENUM('offer','answer','candidate','end') NOT NULL,
    payload     TEXT NOT NULL,
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (call_id) REFERENCES calls(id) ON DELETE CASCADE,
    FOREIGN KEY (from_user) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (to_user) REFERENCES users(id) ON DELETE CASCADE
);

-- ---------------------------------------------------------
-- CHANNELS = disimpan sebagai chats.type='channel'
-- Followers channel disimpan di chat_members (role='member')
-- ---------------------------------------------------------
