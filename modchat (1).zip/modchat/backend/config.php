<?php
/**
 * ModChat - Konfigurasi Database & Helper
 * Dijalankan di Termux: php -S 0.0.0.0:8080 -t backend
 * MySQL/MariaDB dijalankan lokal lewat termux (paket mariadb).
 */

session_start();
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit; }

// --- Ganti sesuai environment Termux kamu ---
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'modchat');
define('DB_USER', 'root');
define('DB_PASS', '');       // isi kalau kamu set password mysql/mariadb
define('UPLOAD_URL', '/uploads');

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
    );
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'DB connection failed: ' . $e->getMessage()]);
    exit;
}

function input() {
    $data = json_decode(file_get_contents('php://input'), true);
    return $data ?? $_POST;
}

function respond($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

function require_login() {
    if (empty($_SESSION['user_id'])) {
        respond(['error' => 'Belum login'], 401);
    }
    return $_SESSION['user_id'];
}

// Generate ModChat ID unik 5 digit angka acak (mis. 48213)
function generate_modchat_id($pdo) {
    do {
        $id = strval(random_int(10000, 99999));
        $stmt = $pdo->prepare("SELECT id FROM users WHERE modchat_id = ?");
        $stmt->execute([$id]);
    } while ($stmt->fetch());
    return $id;
}

function save_upload($field, $folder) {
    if (empty($_FILES[$field]) || $_FILES[$field]['error'] !== UPLOAD_ERR_OK) return null;
    $ext = pathinfo($_FILES[$field]['name'], PATHINFO_EXTENSION);
    $filename = uniqid() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $target = __DIR__ . "/uploads/$folder/$filename";
    move_uploaded_file($_FILES[$field]['tmp_name'], $target);
    return UPLOAD_URL . "/$folder/$filename";
}
