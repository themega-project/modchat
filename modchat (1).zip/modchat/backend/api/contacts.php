<?php
require_once __DIR__ . '/../config.php';
$uid = require_login();
$action = $_GET['action'] ?? '';

switch ($action) {

case 'add':
    $d = input();
    $modchat_id = trim($d['modchat_id'] ?? '');
    $saved_name = trim($d['saved_name'] ?? '');
    $role = trim($d['role'] ?? '') ?: null;

    $stmt = $pdo->prepare("SELECT id FROM users WHERE modchat_id = ?");
    $stmt->execute([$modchat_id]);
    $target = $stmt->fetch();
    if (!$target) respond(['error' => 'ID ModChat tidak ditemukan'], 404);
    if ($target['id'] == $uid) respond(['error' => 'Tidak bisa menambahkan diri sendiri'], 400);

    $stmt = $pdo->prepare("INSERT INTO contacts (owner_id, contact_user_id, saved_name, role) VALUES (?,?,?,?)
        ON DUPLICATE KEY UPDATE saved_name=VALUES(saved_name), role=VALUES(role)");
    $stmt->execute([$uid, $target['id'], $saved_name ?: 'Tanpa Nama', $role]);
    respond(['ok' => true, 'contact_user_id' => $target['id']]);
    break;

case 'list':
    $stmt = $pdo->prepare("
        SELECT c.id, c.saved_name, c.role, c.is_blocked, c.is_muted,
               u.id AS user_id, u.modchat_id, u.avatar, u.bio, u.is_online, u.last_seen
        FROM contacts c JOIN users u ON u.id = c.contact_user_id
        WHERE c.owner_id = ? ORDER BY c.saved_name ASC");
    $stmt->execute([$uid]);
    respond(['contacts' => $stmt->fetchAll()]);
    break;

case 'block':
    $d = input();
    $pdo->prepare("UPDATE contacts SET is_blocked=? WHERE owner_id=? AND contact_user_id=?")
        ->execute([$d['blocked'] ? 1 : 0, $uid, $d['contact_user_id']]);
    respond(['ok' => true]);
    break;

case 'mute':
    $d = input();
    $pdo->prepare("UPDATE contacts SET is_muted=? WHERE owner_id=? AND contact_user_id=?")
        ->execute([$d['muted'] ? 1 : 0, $uid, $d['contact_user_id']]);
    respond(['ok' => true]);
    break;

case 'report':
    // sederhana: dicatat sebagai log teks (bisa dikembangkan ke tabel reports)
    respond(['ok' => true, 'message' => 'Laporan diterima']);
    break;

case 'delete':
    $d = input();
    $pdo->prepare("DELETE FROM contacts WHERE owner_id=? AND contact_user_id=?")
        ->execute([$uid, $d['contact_user_id']]);
    respond(['ok' => true]);
    break;

default:
    respond(['error' => 'Aksi tidak dikenal'], 404);
}
