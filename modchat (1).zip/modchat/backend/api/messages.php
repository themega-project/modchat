<?php
require_once __DIR__ . '/../config.php';
$uid = require_login();
$action = $_GET['action'] ?? '';

switch ($action) {

// Ambil pesan (dipakai untuk load awal & polling realtime pakai ?since_id=)
case 'list':
    $chatId = intval($_GET['chat_id']);
    $sinceId = intval($_GET['since_id'] ?? 0);
    if ($sinceId > 0) {
        $stmt = $pdo->prepare("
            SELECT m.*, u.name AS sender_name, u.avatar AS sender_avatar
            FROM messages m JOIN users u ON u.id = m.sender_id
            WHERE m.chat_id = ? AND m.id > ? ORDER BY m.id ASC");
        $stmt->execute([$chatId, $sinceId]);
    } else {
        $stmt = $pdo->prepare("
            SELECT m.*, u.name AS sender_name, u.avatar AS sender_avatar
            FROM messages m JOIN users u ON u.id = m.sender_id
            WHERE m.chat_id = ? ORDER BY m.id DESC LIMIT 50");
        $stmt->execute([$chatId]);
    }
    $rows = $stmt->fetchAll();
    if ($sinceId == 0) $rows = array_reverse($rows);

    // auto set status delivered utk pesan yg diterima
    foreach ($rows as $r) {
        if ($r['sender_id'] != $uid) {
            $pdo->prepare("INSERT INTO message_status (message_id, user_id, status) VALUES (?,?,'delivered')
                ON DUPLICATE KEY UPDATE status = IF(status='read','read','delivered')")
                ->execute([$r['id'], $uid]);
        }
    }
    respond(['messages' => $rows]);
    break;

// Kirim pesan teks / balasan
case 'send':
    $d = input();
    $chatId = intval($d['chat_id']);
    $stmt = $pdo->prepare("INSERT INTO messages (chat_id, sender_id, type, content, reply_to) VALUES (?,?,?,?,?)");
    $stmt->execute([$chatId, $uid, $d['type'] ?? 'text', $d['content'] ?? '', $d['reply_to'] ?? null]);
    $msgId = $pdo->lastInsertId();
    respond(['ok' => true, 'message_id' => $msgId]);
    break;

// Kirim media (foto/file/voice note/video) via multipart/form-data
case 'send_media':
    $chatId = intval($_POST['chat_id']);
    $type = $_POST['type'] ?? 'file'; // image | file | voice | video
    $folder = $type === 'image' ? 'chat_media' : ($type === 'voice' ? 'chat_media' : 'chat_media');
    $path = save_upload('media', 'chat_media');
    if (!$path) respond(['error' => 'Upload gagal'], 400);
    $stmt = $pdo->prepare("INSERT INTO messages (chat_id, sender_id, type, content, file_path) VALUES (?,?,?,?,?)");
    $stmt->execute([$chatId, $uid, $type, $_POST['caption'] ?? '', $path]);
    respond(['ok' => true, 'message_id' => $pdo->lastInsertId(), 'file_path' => $path]);
    break;

case 'edit':
    $d = input();
    $stmt = $pdo->prepare("UPDATE messages SET content=?, is_edited=1 WHERE id=? AND sender_id=?");
    $stmt->execute([$d['content'], $d['message_id'], $uid]);
    respond(['ok' => true]);
    break;

case 'delete':
    $d = input();
    // hapus_untuk_saya vs hapus_untuk_semua bisa dibedakan; di sini hapus untuk semua jika pengirim
    $stmt = $pdo->prepare("UPDATE messages SET is_deleted=1, content=NULL, file_path=NULL WHERE id=? AND sender_id=?");
    $stmt->execute([$d['message_id'], $uid]);
    respond(['ok' => true]);
    break;

case 'pin':
    $d = input();
    $pdo->prepare("UPDATE messages SET is_pinned=? WHERE id=?")->execute([$d['pinned'] ? 1 : 0, $d['message_id']]);
    respond(['ok' => true]);
    break;

default:
    respond(['error' => 'Aksi tidak dikenal'], 404);
}
