<?php
require_once __DIR__ . '/../config.php';
$uid = require_login();
$action = $_GET['action'] ?? '';

switch ($action) {

case 'create':
    $d = input();
    $name = trim($d['name'] ?? 'Grup Baru');
    $memberIds = $d['member_ids'] ?? []; // array of user_id

    $pdo->beginTransaction();
    $pdo->prepare("INSERT INTO chats (type, name, created_by) VALUES ('group', ?, ?)")->execute([$name, $uid]);
    $chatId = $pdo->lastInsertId();
    $pdo->prepare("INSERT INTO chat_members (chat_id, user_id, role) VALUES (?,?,'owner')")->execute([$chatId, $uid]);
    foreach ($memberIds as $mid) {
        if ($mid == $uid) continue;
        $pdo->prepare("INSERT IGNORE INTO chat_members (chat_id, user_id, role) VALUES (?,?,'member')")
            ->execute([$chatId, $mid]);
    }
    $pdo->commit();
    respond(['ok' => true, 'chat_id' => $chatId]);
    break;

case 'add_member':
    $d = input();
    $pdo->prepare("INSERT IGNORE INTO chat_members (chat_id, user_id, role) VALUES (?,?,'member')")
        ->execute([$d['chat_id'], $d['user_id']]);
    respond(['ok' => true]);
    break;

case 'remove_member':
    $d = input();
    $pdo->prepare("DELETE FROM chat_members WHERE chat_id=? AND user_id=?")
        ->execute([$d['chat_id'], $d['user_id']]);
    respond(['ok' => true]);
    break;

case 'rename':
    $d = input();
    $pdo->prepare("UPDATE chats SET name=? WHERE id=? AND type='group'")->execute([$d['name'], $d['chat_id']]);
    respond(['ok' => true]);
    break;

case 'update_photo':
    $chatId = intval($_POST['chat_id']);
    $path = save_upload('avatar', 'avatars');
    if ($path) $pdo->prepare("UPDATE chats SET avatar=? WHERE id=?")->execute([$path, $chatId]);
    respond(['ok' => true, 'avatar' => $path]);
    break;

case 'members':
    $chatId = intval($_GET['chat_id']);
    $stmt = $pdo->prepare("
        SELECT u.id, u.name, u.avatar, u.modchat_id, cm.role
        FROM chat_members cm JOIN users u ON u.id = cm.user_id
        WHERE cm.chat_id = ?");
    $stmt->execute([$chatId]);
    respond(['members' => $stmt->fetchAll()]);
    break;

case 'leave':
    $d = input();
    $pdo->prepare("DELETE FROM chat_members WHERE chat_id=? AND user_id=?")->execute([$d['chat_id'], $uid]);
    respond(['ok' => true]);
    break;

default:
    respond(['error' => 'Aksi tidak dikenal'], 404);
}
