<?php
require_once __DIR__ . '/../config.php';
$uid = require_login();
$action = $_GET['action'] ?? '';

switch ($action) {

case 'create':
    $d = input();
    $name = trim($d['name'] ?? 'Saluran Baru');
    $desc = trim($d['description'] ?? '');
    $pdo->beginTransaction();
    $pdo->prepare("INSERT INTO chats (type, name, description, created_by) VALUES ('channel', ?, ?, ?)")
        ->execute([$name, $desc, $uid]);
    $chatId = $pdo->lastInsertId();
    $pdo->prepare("INSERT INTO chat_members (chat_id, user_id, role) VALUES (?,?,'owner')")->execute([$chatId, $uid]);
    $pdo->commit();
    respond(['ok' => true, 'chat_id' => $chatId]);
    break;

// Semua saluran yang bisa ditemukan (jelajahi) + tandai mana yang sudah diikuti
case 'discover':
    $stmt = $pdo->prepare("
        SELECT ch.id, ch.name, ch.avatar, ch.description,
            (SELECT COUNT(*) FROM chat_members WHERE chat_id = ch.id) AS followers,
            EXISTS(SELECT 1 FROM chat_members WHERE chat_id = ch.id AND user_id = ?) AS is_following
        FROM chats ch WHERE ch.type = 'channel' ORDER BY followers DESC");
    $stmt->execute([$uid]);
    respond(['channels' => $stmt->fetchAll()]);
    break;

case 'follow':
    $d = input();
    $pdo->prepare("INSERT IGNORE INTO chat_members (chat_id, user_id, role) VALUES (?,?,'member')")
        ->execute([$d['chat_id'], $uid]);
    respond(['ok' => true]);
    break;

case 'unfollow':
    $d = input();
    $pdo->prepare("DELETE FROM chat_members WHERE chat_id=? AND user_id=?")->execute([$d['chat_id'], $uid]);
    respond(['ok' => true]);
    break;

// Posting hanya boleh oleh owner/admin channel -> pakai messages.php (send) dengan chat_id channel,
// tapi kita validasi role di sini sebagai contoh guard tambahan.
case 'post_permission':
    $chatId = intval($_GET['chat_id']);
    $stmt = $pdo->prepare("SELECT role FROM chat_members WHERE chat_id=? AND user_id=?");
    $stmt->execute([$chatId, $uid]);
    $row = $stmt->fetch();
    respond(['can_post' => $row && in_array($row['role'], ['owner','admin'])]);
    break;

default:
    respond(['error' => 'Aksi tidak dikenal'], 404);
}
