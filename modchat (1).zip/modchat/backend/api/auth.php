<?php
require_once __DIR__ . '/../config.php';

$action = $_GET['action'] ?? '';

switch ($action) {

case 'register':
    $d = input();
    $name = trim($d['name'] ?? '');
    $username = trim($d['username'] ?? '');
    $password = $d['password'] ?? '';
    if (!$name || !$username || !$password) respond(['error' => 'Nama, username, password wajib diisi'], 400);

    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->execute([$username]);
    if ($stmt->fetch()) respond(['error' => 'Username sudah dipakai'], 409);

    $modchat_id = generate_modchat_id($pdo);
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO users (modchat_id, name, username, password_hash) VALUES (?,?,?,?)");
    $stmt->execute([$modchat_id, $name, $username, $hash]);
    $userId = $pdo->lastInsertId();

    $_SESSION['user_id'] = $userId;
    respond(['ok' => true, 'user_id' => $userId, 'modchat_id' => $modchat_id]);
    break;

case 'login':
    $d = input();
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$d['username'] ?? '']);
    $user = $stmt->fetch();
    if (!$user || !password_verify($d['password'] ?? '', $user['password_hash'])) {
        respond(['error' => 'Username atau password salah'], 401);
    }
    $_SESSION['user_id'] = $user['id'];
    $pdo->prepare("UPDATE users SET is_online=1, last_seen=NOW() WHERE id=?")->execute([$user['id']]);
    unset($user['password_hash']);
    respond(['ok' => true, 'user' => $user]);
    break;

case 'logout':
    if (!empty($_SESSION['user_id'])) {
        $pdo->prepare("UPDATE users SET is_online=0, last_seen=NOW() WHERE id=?")->execute([$_SESSION['user_id']]);
    }
    session_destroy();
    respond(['ok' => true]);
    break;

case 'me':
    $uid = require_login();
    $stmt = $pdo->prepare("SELECT id, modchat_id, name, username, avatar, bio, chat_background, language, status_privacy, last_seen, is_online FROM users WHERE id=?");
    $stmt->execute([$uid]);
    respond(['user' => $stmt->fetch()]);
    break;

case 'update_profile':
    $uid = require_login();
    $fields = [];
    $params = [];
    foreach (['name','bio','language','status_privacy'] as $f) {
        if (isset($_POST[$f])) { $fields[] = "$f = ?"; $params[] = $_POST[$f]; }
    }
    if (!empty($_FILES['avatar'])) {
        $path = save_upload('avatar', 'avatars');
        if ($path) { $fields[] = "avatar = ?"; $params[] = $path; }
    }
    if ($fields) {
        $params[] = $uid;
        $pdo->prepare("UPDATE users SET " . implode(',', $fields) . " WHERE id=?")->execute($params);
    }
    respond(['ok' => true]);
    break;

case 'update_chat_background':
    $uid = require_login();
    $d = input();
    $pdo->prepare("UPDATE users SET chat_background=? WHERE id=?")->execute([$d['background'] ?? null, $uid]);
    respond(['ok' => true]);
    break;

default:
    respond(['error' => 'Aksi tidak dikenal'], 404);
}
