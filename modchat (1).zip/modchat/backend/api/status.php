<?php
require_once __DIR__ . '/../config.php';
$uid = require_login();
$action = $_GET['action'] ?? '';

switch ($action) {

case 'upload':
    $type = $_POST['type'] ?? 'image'; // image | text
    $caption = $_POST['caption'] ?? '';
    $bg = $_POST['bg_color'] ?? null;
    $path = $type === 'image' ? save_upload('media', 'status') : null;
    $stmt = $pdo->prepare("INSERT INTO statuses (user_id, type, file_path, caption, bg_color, expires_at)
        VALUES (?,?,?,?,?, DATE_ADD(NOW(), INTERVAL 24 HOUR))");
    $stmt->execute([$uid, $type, $path, $caption, $bg]);
    respond(['ok' => true, 'status_id' => $pdo->lastInsertId()]);
    break;

// Status milik kontak-kontak saya (yang belum kadaluarsa), dikelompokkan per user
case 'feed':
    $stmt = $pdo->prepare("
        SELECT s.*, u.name, u.avatar, u.modchat_id,
            EXISTS(SELECT 1 FROM status_views v WHERE v.status_id=s.id AND v.viewer_id=?) AS viewed
        FROM statuses s
        JOIN users u ON u.id = s.user_id
        WHERE s.expires_at > NOW()
          AND (s.user_id = ? OR s.user_id IN (
                SELECT contact_user_id FROM contacts WHERE owner_id = ? AND is_blocked = 0
          ))
        ORDER BY s.created_at DESC");
    $stmt->execute([$uid, $uid, $uid]);
    respond(['statuses' => $stmt->fetchAll()]);
    break;

case 'view':
    $d = input();
    $pdo->prepare("INSERT IGNORE INTO status_views (status_id, viewer_id) VALUES (?,?)")
        ->execute([$d['status_id'], $uid]);
    respond(['ok' => true]);
    break;

case 'viewers':
    $statusId = intval($_GET['status_id']);
    $stmt = $pdo->prepare("
        SELECT u.id, u.name, u.avatar, v.viewed_at
        FROM status_views v JOIN users u ON u.id = v.viewer_id
        WHERE v.status_id = ? ORDER BY v.viewed_at DESC");
    $stmt->execute([$statusId]);
    respond(['viewers' => $stmt->fetchAll()]);
    break;

case 'delete':
    $d = input();
    $pdo->prepare("DELETE FROM statuses WHERE id=? AND user_id=?")->execute([$d['status_id'], $uid]);
    respond(['ok' => true]);
    break;

default:
    respond(['error' => 'Aksi tidak dikenal'], 404);
}
