<?php
require_once __DIR__ . '/../config.php';
$uid = require_login();
$action = $_GET['action'] ?? '';

switch ($action) {

case 'start':
    $d = input();
    $stmt = $pdo->prepare("INSERT INTO calls (chat_id, caller_id, receiver_id, type, status) VALUES (?,?,?,?, 'outgoing')");
    $stmt->execute([$d['chat_id'], $uid, $d['receiver_id'], $d['type'] ?? 'voice']);
    respond(['ok' => true, 'call_id' => $pdo->lastInsertId()]);
    break;

case 'update_status':
    $d = input();
    $duration = null;
    if (($d['status'] ?? '') === 'answered' && !empty($d['ended'])) {
        $pdo->prepare("UPDATE calls SET status=?, ended_at=NOW(), duration_sec=? WHERE id=?")
            ->execute([$d['status'], $d['duration_sec'] ?? 0, $d['call_id']]);
    } else {
        $pdo->prepare("UPDATE calls SET status=? WHERE id=?")->execute([$d['status'], $d['call_id']]);
    }
    respond(['ok' => true]);
    break;

case 'history':
    $stmt = $pdo->prepare("
        SELECT c.*, u.name AS peer_name, u.avatar AS peer_avatar
        FROM calls c
        JOIN users u ON u.id = IF(c.caller_id = ?, c.receiver_id, c.caller_id)
        WHERE c.caller_id = ? OR c.receiver_id = ?
        ORDER BY c.started_at DESC LIMIT 100");
    $stmt->execute([$uid, $uid, $uid]);
    respond(['calls' => $stmt->fetchAll()]);
    break;

// --- Signaling WebRTC sederhana (polling based) ---
case 'signal_send':
    $d = input();
    $stmt = $pdo->prepare("INSERT INTO call_signals (call_id, from_user, to_user, type, payload) VALUES (?,?,?,?,?)");
    $stmt->execute([$d['call_id'], $uid, $d['to_user'], $d['type'], json_encode($d['payload'])]);
    respond(['ok' => true]);
    break;

case 'signal_poll':
    $callId = intval($_GET['call_id']);
    $sinceId = intval($_GET['since_id'] ?? 0);
    $stmt = $pdo->prepare("SELECT * FROM call_signals WHERE call_id=? AND to_user=? AND id > ? ORDER BY id ASC");
    $stmt->execute([$callId, $uid, $sinceId]);
    respond(['signals' => $stmt->fetchAll()]);
    break;

default:
    respond(['error' => 'Aksi tidak dikenal'], 404);
}
