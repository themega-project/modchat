<?php
require_once __DIR__ . '/../config.php';
$uid = require_login();
$action = $_GET['action'] ?? '';

switch ($action) {

// Daftar semua chat milik user (untuk tab "Chat"), + info pesan terakhir
case 'list':
    $sql = "
    SELECT ch.id AS chat_id, ch.type, ch.name, ch.avatar,
           s.is_archived, s.is_muted, s.is_pinned, s.background,
           (SELECT m.content FROM messages m WHERE m.chat_id = ch.id AND m.is_deleted=0
                ORDER BY m.id DESC LIMIT 1) AS last_message,
           (SELECT m.type FROM messages m WHERE m.chat_id = ch.id AND m.is_deleted=0
                ORDER BY m.id DESC LIMIT 1) AS last_type,
           (SELECT m.created_at FROM messages m WHERE m.chat_id = ch.id
                ORDER BY m.id DESC LIMIT 1) AS last_time,
           (SELECT COUNT(*) FROM messages m
                LEFT JOIN message_status st ON st.message_id = m.id AND st.user_id = ?
                WHERE m.chat_id = ch.id AND m.sender_id != ? AND (st.status IS NULL OR st.status != 'read')
           ) AS unread_count
    FROM chats ch
    JOIN chat_members cm ON cm.chat_id = ch.id
    LEFT JOIN chat_user_settings s ON s.chat_id = ch.id AND s.user_id = ?
    WHERE cm.user_id = ?
    ORDER BY last_time DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$uid, $uid, $uid, $uid]);
    $chats = $stmt->fetchAll();

    // Untuk chat privat, tampilkan nama & avatar lawan bicara (bukan nama sendiri)
    foreach ($chats as &$c) {
        if ($c['type'] === 'private') {
            $stmt2 = $pdo->prepare("
                SELECT u.id, u.avatar, u.is_online, u.last_seen, u.modchat_id,
                       COALESCE(ct.saved_name, u.name) AS display_name
                FROM chat_members cm
                JOIN users u ON u.id = cm.user_id
                LEFT JOIN contacts ct ON ct.owner_id = ? AND ct.contact_user_id = u.id
                WHERE cm.chat_id = ? AND cm.user_id != ? LIMIT 1");
            $stmt2->execute([$uid, $c['chat_id'], $uid]);
            $other = $stmt2->fetch();
            if ($other) {
                $c['name'] = $other['display_name'];
                $c['avatar'] = $other['avatar'];
                $c['is_online'] = (bool)$other['is_online'];
                $c['peer_id'] = $other['id'];
            }
        }
    }
    respond(['chats' => $chats]);
    break;

// Buat / ambil chat privat dengan contact_user_id
case 'open_private':
    $d = input();
    $peer = intval($d['contact_user_id']);
    $stmt = $pdo->prepare("
        SELECT cm1.chat_id FROM chat_members cm1
        JOIN chat_members cm2 ON cm1.chat_id = cm2.chat_id
        JOIN chats ch ON ch.id = cm1.chat_id
        WHERE cm1.user_id = ? AND cm2.user_id = ? AND ch.type = 'private'");
    $stmt->execute([$uid, $peer]);
    $row = $stmt->fetch();
    if ($row) respond(['chat_id' => $row['chat_id']]);

    $pdo->beginTransaction();
    $pdo->prepare("INSERT INTO chats (type, created_by) VALUES ('private', ?)")->execute([$uid]);
    $chatId = $pdo->lastInsertId();
    $pdo->prepare("INSERT INTO chat_members (chat_id, user_id) VALUES (?,?),(?,?)")
        ->execute([$chatId, $uid, $chatId, $peer]);
    $pdo->commit();
    respond(['chat_id' => $chatId]);
    break;

case 'archive':
    $d = input();
    upsert_setting($pdo, $d['chat_id'], $uid, 'is_archived', $d['archived'] ? 1 : 0);
    respond(['ok' => true]);
    break;

case 'mute':
    $d = input();
    upsert_setting($pdo, $d['chat_id'], $uid, 'is_muted', $d['muted'] ? 1 : 0);
    respond(['ok' => true]);
    break;

case 'pin':
    $d = input();
    upsert_setting($pdo, $d['chat_id'], $uid, 'is_pinned', $d['pinned'] ? 1 : 0);
    respond(['ok' => true]);
    break;

case 'set_background':
    $d = input();
    upsert_setting($pdo, $d['chat_id'], $uid, 'background', $d['background'] ?? null);
    respond(['ok' => true]);
    break;

// Tandai SEMUA chat sebagai sudah dibaca ("Baca semua")
case 'mark_all_read':
    $stmt = $pdo->prepare("SELECT chat_id FROM chat_members WHERE user_id=?");
    $stmt->execute([$uid]);
    $chatIds = array_column($stmt->fetchAll(), 'chat_id');
    foreach ($chatIds as $cid) {
        mark_chat_read($pdo, $cid, $uid);
    }
    respond(['ok' => true]);
    break;

case 'mark_read':
    $d = input();
    mark_chat_read($pdo, $d['chat_id'], $uid);
    respond(['ok' => true]);
    break;

case 'delete_all_messages':
    $d = input();
    $pdo->prepare("UPDATE messages SET is_deleted=1, content=NULL, file_path=NULL WHERE chat_id=?")
        ->execute([$d['chat_id']]);
    respond(['ok' => true]);
    break;

default:
    respond(['error' => 'Aksi tidak dikenal'], 404);
}

function upsert_setting($pdo, $chatId, $uid, $field, $value) {
    $stmt = $pdo->prepare("INSERT INTO chat_user_settings (chat_id, user_id, $field) VALUES (?,?,?)
        ON DUPLICATE KEY UPDATE $field = VALUES($field)");
    $stmt->execute([$chatId, $uid, $value]);
}

function mark_chat_read($pdo, $chatId, $uid) {
    $stmt = $pdo->prepare("SELECT id FROM messages WHERE chat_id=? AND sender_id != ?");
    $stmt->execute([$chatId, $uid]);
    foreach ($stmt->fetchAll() as $m) {
        $pdo->prepare("INSERT INTO message_status (message_id, user_id, status) VALUES (?,?,'read')
            ON DUPLICATE KEY UPDATE status='read', updated_at=NOW()")->execute([$m['id'], $uid]);
    }
}
