<?php
/**
 * Router untuk PHP built-in server.
 * Jalankan dari folder root project:
 *   php -S 0.0.0.0:8080 router.php
 *
 * - "/"              -> frontend/index.html
 * - "/css/..","/js/.."-> file statis di frontend/
 * - "/api/xxx.php"   -> backend/api/xxx.php
 * - "/uploads/.."    -> file di backend/uploads/
 */

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

if ($uri === '/' || $uri === '') {
    require __DIR__ . '/frontend/index.html';
    return true;
}

if (preg_match('#^/api/#', $uri)) {
    $file = __DIR__ . '/backend' . $uri;
    if (is_file($file)) { require $file; return true; }
    http_response_code(404);
    echo json_encode(['error' => 'Endpoint tidak ditemukan']);
    return true;
}

if (preg_match('#^/uploads/#', $uri)) {
    $file = __DIR__ . '/backend' . $uri;
    if (is_file($file)) {
        $mime = mime_content_type($file);
        header('Content-Type: ' . $mime);
        readfile($file);
        return true;
    }
    http_response_code(404);
    return true;
}

// file statis frontend (css, js, html lain)
$staticFile = __DIR__ . '/frontend' . $uri;
if (is_file($staticFile)) {
    $ext = pathinfo($staticFile, PATHINFO_EXTENSION);
    $mimes = ['css'=>'text/css','js'=>'application/javascript','html'=>'text/html','png'=>'image/png','jpg'=>'image/jpeg','svg'=>'image/svg+xml'];
    header('Content-Type: ' . ($mimes[$ext] ?? 'application/octet-stream'));
    readfile($staticFile);
    return true;
}

http_response_code(404);
echo "404 Not Found";
