# ModChat

Aplikasi chat mirip WhatsApp tanpa perlu nomor HP/SIM card. Setiap user
punya **ModChat ID** (5 angka acak) sebagai pengganti nomor telepon —
dipakai untuk saling menambahkan kontak.

## Fitur

- **Chat**: teks, foto, file, voice note, video, balas pesan, edit, hapus, sematkan
- **Status**: upload foto/teks status yang hidup 24 jam, lihat siapa yang menonton
- **Riwayat panggilan**: log panggilan + panggilan suara/video nyata via WebRTC (signaling polling)
- **Grup**: buat grup, tambah/hapus anggota, ganti nama & foto grup
- **Saluran (channel)**: buat saluran, jelajahi & ikuti saluran orang lain
- **Baca semua**: tandai semua pesan belum dibaca jadi terbaca
- **Settings**: ganti foto profil, nama, bio, background chat, privasi status, notifikasi, bahasa
- **Kontak**: tambah teman pakai ModChat ID + nama simpanan + role opsional (teman/guru/bos/dll.)
- **Per-chat**: blokir, laporkan, senyapkan notifikasi, arsipkan chat, hapus semua pesan, ganti background

## Struktur Folder

```
modchat/
├── database/schema.sql     -> struktur database MySQL/MariaDB
├── backend/
│   ├── config.php          -> koneksi DB & helper
│   ├── api/*.php           -> semua endpoint REST API
│   └── uploads/            -> penyimpanan foto/file/voice note
├── frontend/
│   ├── index.html
│   ├── css/style.css       -> tampilan mirip WhatsApp (tema hijau/gelap)
│   └── js/app.js           -> semua logic frontend (vanilla JS, tanpa framework)
└── router.php              -> router agar `php -S` bisa serve semuanya jadi satu
```

## Menjalankan di Termux (database realtime, lokal di HP)

1. **Install paket dasar di Termux:**
   ```bash
   pkg update && pkg upgrade -y
   pkg install php mariadb git -y
   ```

2. **Nyalakan MariaDB:**
   ```bash
   mariadb-install-db --datadir=$PREFIX/var/lib/mysql
   mysqld_safe --datadir=$PREFIX/var/lib/mysql &
   ```
   Buka terminal baru (atau `termux-wake-lock` biar proses tetap jalan), lalu buat database:
   ```bash
   mysql -u root
   ```
   ```sql
   -- di dalam prompt mysql:
   source /data/data/com.termux/files/home/modchat/database/schema.sql;
   exit;
   ```
   (Sesuaikan path `source` dengan lokasi folder `modchat` kamu di Termux.)

3. **Clone project dari GitHub** (setelah kamu push, lihat bagian di bawah):
   ```bash
   git clone https://github.com/USERNAME_KAMU/modchat.git
   cd modchat
   ```

4. **Cek `backend/config.php`** — pastikan `DB_USER`/`DB_PASS` sesuai setup MariaDB kamu.

5. **Jalankan server PHP:**
   ```bash
   php -S 0.0.0.0:8080 router.php
   ```

6. **Buka di browser HP** (Chrome dsb.): `http://localhost:8080`
   Kalau mau diakses dari device lain di jaringan yang sama, pakai IP lokal HP, misalnya `http://192.168.1.x:8080`.

> Database `mariadb` di Termux berjalan langsung di penyimpanan HP, jadi data
> tersimpan realtime selama server aktif — persis seperti yang kamu minta.

## Menyimpan Kode ke GitHub

```bash
cd modchat
git init
git add .
git commit -m "Initial commit - ModChat"
git branch -M main
git remote add origin https://github.com/USERNAME_KAMU/modchat.git
git push -u origin main
```

**Catatan penting:** jangan push folder `backend/uploads/*` yang berisi file
pengguna asli (foto/voice note) dan jangan push kredensial database asli ke
repo publik. Tambahkan `.gitignore` berikut sebelum push pertama:

```
backend/uploads/**/*.jpg
backend/uploads/**/*.png
backend/uploads/**/*.webm
backend/uploads/**/*.mp4
```

## Cara Kerja Realtime

- **Chat**: frontend melakukan polling (`setInterval`) tiap 2.5 detik ke
  `messages.php?action=list&since_id=...` sehingga pesan baru langsung muncul
  tanpa reload. Ini dipilih supaya cukup dijalankan dengan PHP built-in server
  di Termux tanpa perlu setup WebSocket server terpisah.
- **Panggilan suara/video**: menggunakan WebRTC asli di browser (kamera/mikrofon
  HP), dengan signaling (offer/answer/ICE candidate) dikirim lewat polling ke
  `calls.php?action=signal_*`. Untuk panggilan lintas jaringan (bukan WiFi yang
  sama), kamu mungkin perlu menambahkan TURN server karena STUN publik saja
  kadang tidak cukup menembus NAT operator seluler.

## Pengembangan Lanjutan (opsional)

- Ganti polling dengan WebSocket (misalnya pakai ekstensi `swoole` atau
  library `ratchet/pawl` via Composer) kalau ingin latensi lebih rendah.
- Tambahkan push notification (service worker) agar notifikasi muncul walau
  tab browser tidak aktif.
- Tambahkan enkripsi end-to-end untuk isi pesan bila dibutuhkan.
