// =======================================================
// ModChat - Frontend Application Logic
// =======================================================
const API = '/api'; // relative ke backend, lihat README utk setup

let ME = null;                 // profil user login
let currentChatId = null;
let currentPeerId = null;
let currentChatType = null;
let lastMsgId = 0;
let replyToId = null;
let pollTimer = null;
let chatListTimer = null;
const BG_COLORS = ['#0b141a','#182229','#1f2c34','#0d3b34','#2b1f34','#3a1f1f','#1f2a3a'];

async function api(path, opts = {}) {
  const res = await fetch(API + path, {
    credentials: 'include',
    headers: opts.body instanceof FormData ? {} : {'Content-Type':'application/json'},
    ...opts
  });
  return res.json();
}
function el(id){ return document.getElementById(id); }
function esc(s){ return (s||'').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function timeAgo(dt){
  if(!dt) return '';
  const d = new Date(dt.replace(' ','T'));
  return d.toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'});
}

// =================== AUTH ===================
const Auth = {
  showRegister(){ el('loginForm').classList.add('hidden'); el('registerForm').classList.remove('hidden'); },
  showLogin(){ el('registerForm').classList.add('hidden'); el('loginForm').classList.remove('hidden'); },

  async register(){
    const r = await api('/auth.php?action=register', {method:'POST', body: JSON.stringify({
      name: el('regName').value.trim(),
      username: el('regUsername').value.trim(),
      password: el('regPassword').value
    })});
    if (r.error) { el('regError').textContent = r.error; return; }
    alert('Akun dibuat! ModChat ID kamu: ' + r.modchat_id + ' (simpan baik-baik)');
    await App.boot();
  },

  async login(){
    const r = await api('/auth.php?action=login', {method:'POST', body: JSON.stringify({
      username: el('loginUsername').value.trim(),
      password: el('loginPassword').value
    })});
    if (r.error) { el('loginError').textContent = r.error; return; }
    await App.boot();
  },

  async logout(){
    await api('/auth.php?action=logout', {method:'POST'});
    location.reload();
  }
};

// =================== UI helpers ===================
const UI = {
  switchTab(tab){
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
    const target = el('tab-' + tab);
    if (target) target.classList.add('active');
    el('mainMenu').classList.add('hidden');
    if (tab === 'status') Status.load();
    if (tab === 'calls') Calls.loadHistory();
    if (tab === 'channels') Channels.discover();
    if (tab === 'settings') Settings.render();
  },
  toggleMenu(){ el('mainMenu').classList.toggle('hidden'); },
  toggleChatMenu(){ el('chatMenu').classList.toggle('hidden'); },
  openModal(id){ el(id).classList.remove('hidden'); el('mainMenu').classList.add('hidden'); el('chatMenu')?.classList.add('hidden');
    if (id === 'newChatModal') Contacts.renderPicker('contactPickList');
    if (id === 'newGroupModal') Contacts.renderPicker('groupMemberPicker', true);
    if (id === 'chatBgModal') Settings.renderBgOptions('bgOptionsGlobal', false);
    if (id === 'chatBgSingleModal') Settings.renderBgOptions('bgOptionsSingle', true);
    if (id === 'profileModal') Contacts.showProfile(currentPeerId);
  },
  closeModal(id){ el(id).classList.add('hidden'); },
  openNewChatMenu(){ UI.openModal('newChatModal'); }
};
document.addEventListener('click', (e) => {
  if (!e.target.closest('.sidebar-header-icons') && !e.target.closest('#mainMenu')) el('mainMenu')?.classList.add('hidden');
  if (!e.target.closest('.chat-header-icons') && !e.target.closest('#chatMenu')) el('chatMenu')?.classList.add('hidden');
});

// =================== CONTACTS ===================
const Contacts = {
  list: [],
  async load(){
    const r = await api('/contacts.php?action=list');
    this.list = r.contacts || [];
  },
  async add(){
    const modchat_id = el('addModchatId').value.trim();
    const saved_name = el('addContactName').value.trim() || 'Tanpa Nama';
    const role = el('addContactRole').value.trim();
    const r = await api('/contacts.php?action=add', {method:'POST', body: JSON.stringify({modchat_id, saved_name, role})});
    if (r.error) { alert(r.error); return; }
    await this.load();
    this.renderPicker('contactPickList');
    el('addModchatId').value=''; el('addContactName').value=''; el('addContactRole').value='';
  },
  renderPicker(containerId, checkbox=false){
    const c = el(containerId);
    c.innerHTML = this.list.map(ct => `
      <div class="list-item" onclick="${checkbox ? `Contacts.toggleCheck(this, ${ct.user_id})` : `Chats.openWith(${ct.user_id})`}">
        <img class="avatar" src="${ct.avatar || 'https://api.dicebear.com/7.x/initials/svg?seed=' + ct.saved_name}">
        <div class="list-item-info">
          <div class="top-row"><b>${esc(ct.saved_name)}</b></div>
          <div class="bottom-row">${ct.role ? esc(ct.role) + ' · ' : ''}ID ${ct.modchat_id}</div>
        </div>
        ${checkbox ? `<input type="checkbox" data-uid="${ct.user_id}">` : ''}
      </div>`).join('') || '<p style="padding:16px;color:var(--wa-text-dim)">Belum ada kontak.</p>';
  },
  toggleCheck(row, uid){
    const cb = row.querySelector('input[type=checkbox]');
    cb.checked = !cb.checked;
  },
  async toggleBlock(userId){
    const ct = this.list.find(c => c.user_id === userId);
    const blocked = !(ct && ct.is_blocked);
    await api('/contacts.php?action=block', {method:'POST', body: JSON.stringify({contact_user_id:userId, blocked})});
    await this.load();
    alert(blocked ? 'Kontak diblokir' : 'Blokir dibuka');
  },
  async toggleMute(userId){
    const ct = this.list.find(c => c.user_id === userId);
    const muted = !(ct && ct.is_muted);
    await api('/contacts.php?action=mute', {method:'POST', body: JSON.stringify({contact_user_id:userId, muted})});
    await this.load();
    alert(muted ? 'Notifikasi disenyapkan' : 'Notifikasi diaktifkan lagi');
  },
  async report(userId){
    await api('/contacts.php?action=report', {method:'POST', body: JSON.stringify({contact_user_id:userId})});
    alert('Laporan terkirim. Terima kasih.');
  },
  showProfile(userId){
    const ct = this.list.find(c => c.user_id === userId);
    el('profileModalAvatar').src = (ct && ct.avatar) || 'https://api.dicebear.com/7.x/initials/svg?seed=' + (ct ? ct.saved_name : '?');
    el('profileModalName').textContent = ct ? ct.saved_name : el('peerName').textContent;
    el('profileModalId').textContent = ct ? ('ID: ' + ct.modchat_id) : '';
    el('profileModalBio').textContent = (ct && ct.bio) || '';
  }
};

// =================== CHATS (daftar percakapan) ===================
const Chats = {
  list: [],
  async load(){
    const r = await api('/chats.php?action=list');
    this.list = (r.chats || []).filter(c => !c.is_archived);
    this.render();
  },
  render(){
    const q = (el('chatSearch').value || '').toLowerCase();
    const items = this.list.filter(c => (c.name||'').toLowerCase().includes(q));
    el('chatList').innerHTML = items.map(c => `
      <div class="list-item ${c.chat_id===currentChatId?'active':''}" onclick="Chats.open(${c.chat_id}, ${c.peer_id||'null'}, '${c.type}')">
        <img class="avatar" src="${c.avatar || 'https://api.dicebear.com/7.x/initials/svg?seed=' + (c.name||'?')}">
        <div class="list-item-info">
          <div class="top-row"><b>${esc(c.name || 'Tanpa nama')}</b><span>${timeAgo(c.last_time)}</span></div>
          <div class="bottom-row"><span>${c.last_type==='image'?'📷 Foto':c.last_type==='file'?'📎 File':c.last_type==='voice'?'🎤 Pesan suara':c.last_type==='video'?'🎥 Video':esc((c.last_message||'').slice(0,30))}</span>
          ${c.unread_count>0 ? `<span class="unread-badge">${c.unread_count}</span>` : ''}</div>
        </div>
      </div>`).join('') || '<p style="padding:16px;color:var(--wa-text-dim)">Belum ada chat. Tambah kontak dulu.</p>';
  },
  async openWith(userId){
    UI.closeModal('newChatModal');
    const r = await api('/chats.php?action=open_private', {method:'POST', body: JSON.stringify({contact_user_id:userId})});
    await this.load();
    this.open(r.chat_id, userId, 'private');
  },
  open(chatId, peerId, type){
    currentChatId = chatId; currentPeerId = peerId; currentChatType = type;
    lastMsgId = 0;
    el('chatEmpty').classList.add('hidden');
    el('chatActive').classList.remove('hidden');
    document.getElementById('app').classList.add('chat-open');
    const chat = this.list.find(c => c.chat_id === chatId);
    el('peerName').textContent = chat ? chat.name : 'Chat';
    el('peerAvatar').src = (chat && chat.avatar) || 'https://api.dicebear.com/7.x/initials/svg?seed=' + (chat?chat.name:'?');
    el('peerStatusText').textContent = type === 'private' ? (chat && chat.is_online ? 'online' : 'offline') : (type==='group'?'Grup':'Saluran');
    el('messagesArea').innerHTML = '';
    Chat.applyBackground(chat ? chat.background : null);
    Chat.loadMessages();
    api('/chats.php?action=mark_read', {method:'POST', body: JSON.stringify({chat_id:chatId})});
    clearInterval(pollTimer);
    pollTimer = setInterval(Chat.loadMessages, 2500);
  },
  async markAllRead(){
    await api('/chats.php?action=mark_all_read', {method:'POST'});
    await this.load();
  },
  async archiveCurrent(){
    if(!currentChatId) return;
    await api('/chats.php?action=archive', {method:'POST', body: JSON.stringify({chat_id:currentChatId, archived:true})});
    await this.load();
    el('chatActive').classList.add('hidden'); el('chatEmpty').classList.remove('hidden');
  },
  async deleteAllMessages(){
    if(!currentChatId || !confirm('Hapus semua pesan di chat ini?')) return;
    await api('/chats.php?action=delete_all_messages', {method:'POST', body: JSON.stringify({chat_id:currentChatId})});
    Chat.loadMessages(true);
  }
};

// =================== CHAT (pesan dalam 1 percakapan) ===================
const Chat = {
  cancelReply(){ replyToId = null; el('replyPreview').classList.add('hidden'); },

  applyBackground(bg){
    el('messagesArea').style.background = bg ? bg : (ME && ME.chat_background ? ME.chat_background : '');
  },

  async loadMessages(reset=false){
    if (!currentChatId) return;
    const since = reset ? 0 : lastMsgId;
    const r = await api(`/messages.php?action=list&chat_id=${currentChatId}&since_id=${since}`);
    const msgs = r.messages || [];
    if (reset) el('messagesArea').innerHTML = '';
    msgs.forEach(m => { this.renderMessage(m); lastMsgId = Math.max(lastMsgId, m.id); });
    if (msgs.length) el('messagesArea').scrollTop = el('messagesArea').scrollHeight;
  },

  renderMessage(m){
    const mine = m.sender_id == ME.id;
    const div = document.createElement('div');
    div.className = 'bubble ' + (mine?'out':'in') + (m.is_pinned?' pinned':'') + (m.is_deleted?' deleted':'');
    div.id = 'msg-' + m.id;
    let body = '';
    if (m.is_deleted) {
      body = '<i>Pesan telah dihapus</i>';
    } else if (m.type === 'image') {
      body = `<img class="media" src="${m.file_path}">` + (m.content?esc(m.content):'');
    } else if (m.type === 'file') {
      body = `📎 <a href="${m.file_path}" target="_blank" style="color:inherit">${esc(m.content||'File')}</a>`;
    } else if (m.type === 'voice') {
      body = `<audio controls src="${m.file_path}"></audio>`;
    } else if (m.type === 'video') {
      body = `<video controls class="media" src="${m.file_path}"></video>`;
    } else {
      body = esc(m.content||'');
    }
    div.innerHTML = `
      ${!m.is_deleted ? `<span class="bubble-menu-trigger" onclick="Chat.toggleBubbleMenu(${m.id}, event)">⋮</span>` : ''}
      ${body}
      <div class="meta">${m.is_edited?'diedit · ':''}${timeAgo(m.created_at)}</div>
      <div class="bubble-actions hidden" id="actions-${m.id}">
        <div onclick="Chat.setReply(${m.id})">↩️ Balas</div>
        ${mine ? `<div onclick="Chat.editMessage(${m.id})">✏️ Edit pesan</div>` : ''}
        <div onclick="Chat.pinMessage(${m.id}, ${!m.is_pinned})">📌 ${m.is_pinned?'Lepas sematan':'Sematkan pesan'}</div>
        ${mine ? `<div onclick="Chat.deleteMessage(${m.id})">🗑️ Hapus pesan</div>` : ''}
      </div>`;
    const old = el('msg-' + m.id);
    if (old) old.replaceWith(div); else el('messagesArea').appendChild(div);
  },

  toggleBubbleMenu(id, e){ e.stopPropagation(); el('actions-'+id).classList.toggle('hidden'); },
  setReply(id){ replyToId = id; el('replyText').textContent = 'Pesan #' + id; el('replyPreview').classList.remove('hidden');
    document.getElementById('actions-'+id).classList.add('hidden'); },
  async editMessage(id){
    const newText = prompt('Edit pesan:');
    if (newText == null) return;
    await api('/messages.php?action=edit', {method:'POST', body: JSON.stringify({message_id:id, content:newText})});
    this.loadMessages(true);
  },
  async deleteMessage(id){
    if (!confirm('Hapus pesan ini?')) return;
    await api('/messages.php?action=delete', {method:'POST', body: JSON.stringify({message_id:id})});
    this.loadMessages(true);
  },
  async pinMessage(id, pinned){
    await api('/messages.php?action=pin', {method:'POST', body: JSON.stringify({message_id:id, pinned})});
    this.loadMessages(true);
  },

  async sendText(){
    const input = el('messageInput');
    const text = input.value.trim();
    if (!text || !currentChatId) return;
    input.value = '';
    await api('/messages.php?action=send', {method:'POST', body: JSON.stringify({chat_id:currentChatId, type:'text', content:text, reply_to:replyToId})});
    this.cancelReply();
    this.loadMessages();
  },

  async sendFile(e){
    const file = e.target.files[0];
    if (!file || !currentChatId) return;
    const type = file.type.startsWith('image/') ? 'image' : (file.type.startsWith('video/') ? 'video' : 'file');
    const fd = new FormData();
    fd.append('media', file); fd.append('chat_id', currentChatId); fd.append('type', type); fd.append('caption', file.name);
    await api('/messages.php?action=send_media', {method:'POST', body: fd});
    e.target.value = '';
    this.loadMessages();
  },

  // Voice note pakai MediaRecorder API (perlu izin mikrofon)
  mediaRecorder: null, chunks: [],
  async startVoiceNote(){
    try {
      const stream = await navigator.mediaDevices.getUserMedia({audio:true});
      this.chunks = [];
      this.mediaRecorder = new MediaRecorder(stream);
      this.mediaRecorder.ondataavailable = e => this.chunks.push(e.data);
      this.mediaRecorder.start();
      el('micBtn').style.background = '#e53935';
    } catch(err){ console.log('Mic tidak tersedia:', err); }
  },
  stopVoiceNote(){
    if (!this.mediaRecorder) return;
    el('micBtn').style.background = '';
    this.mediaRecorder.onstop = async () => {
      const blob = new Blob(this.chunks, {type:'audio/webm'});
      if (blob.size < 500) return; // terlalu pendek, batalkan
      const fd = new FormData();
      fd.append('media', blob, 'voice.webm'); fd.append('chat_id', currentChatId); fd.append('type', 'voice');
      await api('/messages.php?action=send_media', {method:'POST', body: fd});
      Chat.loadMessages();
    };
    this.mediaRecorder.stop();
  }
};

// =================== GROUPS ===================
const Groups = {
  async create(){
    const name = el('newGroupName').value.trim() || 'Grup Baru';
    const checked = [...document.querySelectorAll('#groupMemberPicker input[type=checkbox]:checked')].map(c => parseInt(c.dataset.uid));
    const r = await api('/groups.php?action=create', {method:'POST', body: JSON.stringify({name, member_ids:checked})});
    UI.closeModal('newGroupModal');
    await Chats.load();
    if (r.chat_id) Chats.open(r.chat_id, null, 'group');
  },
  async rename(chatId){
    const name = prompt('Nama grup baru:');
    if (!name) return;
    await api('/groups.php?action=rename', {method:'POST', body: JSON.stringify({chat_id:chatId, name})});
    Chats.load();
  }
};

// =================== CHANNELS ===================
const Channels = {
  list: [],
  async create(){
    const name = el('newChannelName').value.trim() || 'Saluran Baru';
    const description = el('newChannelDesc').value.trim();
    const r = await api('/channels.php?action=create', {method:'POST', body: JSON.stringify({name, description})});
    UI.closeModal('newChannelModal');
    await Chats.load();
    if (r.chat_id) Chats.open(r.chat_id, null, 'channel');
  },
  async discover(){
    const r = await api('/channels.php?action=discover');
    this.list = r.channels || [];
    el('channelList').innerHTML = this.list.map(c => `
      <div class="list-item">
        <img class="avatar" src="${c.avatar || 'https://api.dicebear.com/7.x/initials/svg?seed='+c.name}">
        <div class="list-item-info">
          <div class="top-row"><b>${esc(c.name)}</b></div>
          <div class="bottom-row">${c.followers} pengikut</div>
        </div>
        <button class="mini-btn" onclick="Channels.toggleFollow(${c.id}, ${c.is_following?0:1})">${c.is_following?'Diikuti':'Ikuti'}</button>
      </div>`).join('') || '<p style="padding:16px;color:var(--wa-text-dim)">Belum ada saluran.</p>';
  },
  async toggleFollow(chatId, follow){
    await api(`/channels.php?action=${follow?'follow':'unfollow'}`, {method:'POST', body: JSON.stringify({chat_id:chatId})});
    this.discover();
    Chats.load();
  }
};

// =================== STATUS ===================
const Status = {
  items: [],
  async load(){
    const r = await api('/status.php?action=feed');
    this.items = r.statuses || [];
    const grouped = {};
    this.items.forEach(s => { (grouped[s.user_id] = grouped[s.user_id] || []).push(s); });
    el('statusList').innerHTML = Object.values(grouped).map(group => {
      const s = group[0];
      const allViewed = group.every(x => x.viewed);
      return `<div class="list-item" onclick='Status.view(${s.user_id})'>
        <img class="status-ring ${allViewed?'viewed':''}" src="${s.avatar || 'https://api.dicebear.com/7.x/initials/svg?seed='+s.name}">
        <div class="list-item-info">
          <div class="top-row"><b>${esc(s.name)}</b></div>
          <div class="bottom-row">${timeAgo(s.created_at)}</div>
        </div>
      </div>`;
    }).join('') || '<p style="padding:16px;color:var(--wa-text-dim)">Belum ada update status.</p>';
  },
  async upload(e){
    const file = e.target.files[0];
    if (!file) return;
    const fd = new FormData();
    fd.append('media', file); fd.append('type', 'image'); fd.append('caption', '');
    await api('/status.php?action=upload', {method:'POST', body: fd});
    e.target.value='';
    this.load();
    alert('Status berhasil diunggah (aktif 24 jam)');
  },
  view(userId){
    const items = this.items.filter(s => s.user_id === userId);
    if (!items.length) return;
    let idx = 0;
    const show = () => {
      const s = items[idx];
      api('/status.php?action=view', {method:'POST', body: JSON.stringify({status_id:s.id})});
      el('statusViewerContent').innerHTML = s.type === 'image'
        ? `<img src="${s.file_path}"><p>${esc(s.caption||'')}</p>`
        : `<div style="background:${s.bg_color||'#222'};padding:60px 20px;border-radius:8px;font-size:20px">${esc(s.caption||'')}</div>`;
    };
    show();
    el('statusViewerModal').classList.remove('hidden');
    el('statusViewerModal').onclick = (ev) => {
      if (ev.target.closest('.status-close')) return;
      idx++;
      if (idx >= items.length) { UI.closeModal('statusViewerModal'); return; }
      show();
    };
  }
};

// =================== SETTINGS ===================
const Settings = {
  render(){
    el('settingsAvatar').src = ME.avatar || 'https://api.dicebear.com/7.x/initials/svg?seed='+ME.name;
    el('settingsName').textContent = ME.name;
    el('settingsBio').textContent = ME.bio || '';
    el('settingsModchatId').textContent = ME.modchat_id;
    el('notifState').textContent = Notification && Notification.permission === 'granted' ? '(aktif)' : '(nonaktif)';
  },
  previewAvatar(e){
    const file = e.target.files[0];
    if (file) el('editAvatarPreview').src = URL.createObjectURL(file);
  },
  async saveProfile(){
    const fd = new FormData();
    fd.append('name', el('editName').value.trim());
    fd.append('bio', el('editBio').value.trim());
    const fileInput = el('editAvatarInput');
    if (fileInput.files[0]) fd.append('avatar', fileInput.files[0]);
    await api('/auth.php?action=update_profile', {method:'POST', body: fd});
    await App.loadMe();
    UI.closeModal('editProfileModal');
  },
  renderBgOptions(containerId, single){
    el(containerId).innerHTML = BG_COLORS.map(c => `<div class="bg-swatch" style="background:${c}" onclick="Settings.pickBg('${c}', ${single})"></div>`).join('');
  },
  async pickBg(color, single){
    if (single && currentChatId) {
      await api('/chats.php?action=set_background', {method:'POST', body: JSON.stringify({chat_id:currentChatId, background:color})});
      Chat.applyBackground(color);
      UI.closeModal('chatBgSingleModal');
    } else {
      await api('/auth.php?action=update_chat_background', {method:'POST', body: JSON.stringify({background:color})});
      ME.chat_background = color;
      Chat.applyBackground(null);
      UI.closeModal('chatBgModal');
    }
  },
  async savePrivacy(){
    const fd = new FormData();
    fd.append('status_privacy', el('statusPrivacySelect').value);
    await api('/auth.php?action=update_profile', {method:'POST', body: fd});
    UI.closeModal('privacyModal');
  },
  async saveLanguage(){
    const fd = new FormData();
    fd.append('language', el('languageSelect').value);
    await api('/auth.php?action=update_profile', {method:'POST', body: fd});
    UI.closeModal('languageModal');
  },
  toggleNotif(){
    if (Notification.permission !== 'granted') Notification.requestPermission().then(() => this.render());
    else alert('Notifikasi sudah aktif. Untuk menonaktifkan, atur lewat pengaturan browser.');
  }
};

// =================== CALLS (riwayat + WebRTC sederhana) ===================
const Calls = {
  history: [],
  pc: null, localStream: null, currentCallId: null, signalTimer: null,

  async loadHistory(){
    const r = await api('/calls.php?action=history');
    this.history = r.calls || [];
    el('callList').innerHTML = this.history.map(c => `
      <div class="list-item">
        <img class="avatar" src="${c.peer_avatar || 'https://api.dicebear.com/7.x/initials/svg?seed='+c.peer_name}">
        <div class="list-item-info">
          <div class="top-row"><b>${esc(c.peer_name)}</b></div>
          <div class="bottom-row">${c.type==='video'?'🎥':'📞'} ${c.status==='missed'?'Tidak terjawab':c.status} · ${timeAgo(c.started_at)}</div>
        </div>
      </div>`).join('') || '<p style="padding:16px;color:var(--wa-text-dim)">Belum ada riwayat panggilan.</p>';
  },

  async startCall(type){
    if (!currentPeerId) { alert('Panggilan hanya tersedia di chat pribadi.'); return; }
    const r = await api('/calls.php?action=start', {method:'POST', body: JSON.stringify({chat_id:currentChatId, receiver_id:currentPeerId, type})});
    this.currentCallId = r.call_id;
    el('callPeerAvatar').src = el('peerAvatar').src;
    el('callPeerName').textContent = el('peerName').textContent;
    el('callStatusText').textContent = 'Memanggil...';
    el('callModal').classList.remove('hidden');

    try {
      this.localStream = await navigator.mediaDevices.getUserMedia({audio:true, video: type==='video'});
      if (type === 'video') { el('localVideo').srcObject = this.localStream; el('localVideo').classList.remove('hidden'); }
      this.pc = new RTCPeerConnection({iceServers:[{urls:'stun:stun.l.google.com:19302'}]});
      this.localStream.getTracks().forEach(t => this.pc.addTrack(t, this.localStream));
      this.pc.ontrack = (e) => { el('remoteVideo').srcObject = e.streams[0]; el('remoteVideo').classList.remove('hidden'); };
      this.pc.onicecandidate = (e) => { if (e.candidate) this.sendSignal('candidate', e.candidate); };
      const offer = await this.pc.createOffer();
      await this.pc.setLocalDescription(offer);
      this.sendSignal('offer', offer);
      this.pollSignals();
    } catch(err){
      alert('Tidak bisa mengakses kamera/mikrofon: ' + err.message);
    }
  },

  async sendSignal(type, payload){
    await api('/calls.php?action=signal_send', {method:'POST', body: JSON.stringify({
      call_id:this.currentCallId, to_user:currentPeerId, type, payload
    })});
  },

  pollSignals(){
    let sinceId = 0;
    clearInterval(this.signalTimer);
    this.signalTimer = setInterval(async () => {
      if (!this.currentCallId) return;
      const r = await api(`/calls.php?action=signal_poll&call_id=${this.currentCallId}&since_id=${sinceId}`);
      for (const s of (r.signals||[])) {
        sinceId = s.id;
        const payload = JSON.parse(s.payload);
        if (s.type === 'answer') { await this.pc.setRemoteDescription(payload); el('callStatusText').textContent = 'Tersambung'; }
        else if (s.type === 'candidate') { try{ await this.pc.addIceCandidate(payload); }catch(e){} }
        else if (s.type === 'end') { this.endCall(true); }
      }
    }, 1500);
  },

  endCall(remote=false){
    if (!remote) this.sendSignal('end', {});
    clearInterval(this.signalTimer);
    if (this.pc) this.pc.close();
    if (this.localStream) this.localStream.getTracks().forEach(t => t.stop());
    el('callModal').classList.add('hidden');
    el('remoteVideo').classList.add('hidden'); el('localVideo').classList.add('hidden');
    if (this.currentCallId) {
      api('/calls.php?action=update_status', {method:'POST', body: JSON.stringify({call_id:this.currentCallId, status:'answered', ended:true, duration_sec:0})});
    }
    this.currentCallId = null;
    this.loadHistory();
  }
};

// =================== APP BOOTSTRAP ===================
const App = {
  async boot(){
    const r = await api('/auth.php?action=me');
    if (r.error) { el('authScreen').classList.remove('hidden'); el('app').classList.add('hidden'); return; }
    ME = r.user;
    el('authScreen').classList.add('hidden');
    el('app').classList.remove('hidden');
    el('myAvatar').src = ME.avatar || 'https://api.dicebear.com/7.x/initials/svg?seed='+ME.name;
    el('myAvatarStatus').src = el('myAvatar').src;
    await Contacts.load();
    await Chats.load();
    clearInterval(chatListTimer);
    chatListTimer = setInterval(() => Chats.load(), 4000);
  },
  async loadMe(){
    const r = await api('/auth.php?action=me');
    ME = r.user;
    el('myAvatar').src = ME.avatar || 'https://api.dicebear.com/7.x/initials/svg?seed='+ME.name;
    Settings.render();
  }
};

el('chatSearch') && el('chatSearch').addEventListener('input', () => Chats.render());
App.boot();
